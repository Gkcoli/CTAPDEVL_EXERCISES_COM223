package com.example.midterms

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class ThirdActivity : AppCompatActivity() {
    lateinit var buttonGoToGithub: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            val user = intent.getStringExtra("User")

            val uuia = findViewById<TextView>(R.id.inputtwo)
            buttonGoToGithub = findViewById(R.id.buttonGoToGithub)
            uuia.setText(user)
            buttonGoToGithub.setOnClickListener {
                val url = "https://github.com/Gkcoli"
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse(url)
                }
                startActivity(intent)
            }
            insets
        }
    }

    fun handleGoToGithubClick(view: View) {
        val intent = Intent(this, SecondActivity::class.java)
        startActivity(intent)
    }

    override fun onStart() {
        super.onStart()
        Log.d("act3onstart", "onStart: Activity Visible")
    }

    override fun onResume() {
        super.onResume()
        Log.d("act3onresume", "onResume: Activity Resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("act3onpause", "onPause: Activity Paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("act3onstop", "onStop: Activity Stopped")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("act3onrestart", "onRestart: Activity Restarted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("act3ondestroy", "onDestroy: Activity Destroyed")
    }
}
