package com.example.midterms


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FirstActivity : AppCompatActivity() {
    lateinit var usernameInput: EditText
    lateinit var buttonSecondActivity: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_first)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            val usernameInput = findViewById<EditText>(R.id.username_input)
            buttonSecondActivity = findViewById(R.id.buttonSecondActivity)
            buttonSecondActivity.setOnClickListener {

                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("User", usernameInput.text.toString()
                )  // Passing user data
                startActivity(intent)

            }
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
    }
    fun handleSecondActivityClick(view: View) {
    }

    override fun onStart() {
        super.onStart()
        Log.d("act1onstart", "onStart: Activity Visible")
    }

    override fun onResume() {
        super.onResume()
        Log.d("act1onstart", "onResume: Activity Resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("act1onstart", "onPause: Activity Paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("act1onstart", "onStop: Activity Stopped")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("act1onstart", "onRestart: Activity Restarted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("act1onstart", "onDestroy: Activity Destroyed")
    }
}